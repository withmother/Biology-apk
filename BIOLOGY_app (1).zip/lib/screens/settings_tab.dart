import 'package:flutter/material.dart';
class SettingsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(child: Text('Settings & Profile'));
}