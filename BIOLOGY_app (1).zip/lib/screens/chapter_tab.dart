import 'package:flutter/material.dart';
class ChapterTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(child: Text('Chapter Mastery'));
}