import 'package:flutter/material.dart';
class AnalyticsTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(child: Text('Analytics & Heatmap'));
}