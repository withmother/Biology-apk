import 'package:flutter/material.dart';
class QuestionTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(child: Text('Question Bank'));
}