import 'package:flutter/foundation.dart';
class AnalyticsService extends ChangeNotifier {
  static final instance = AnalyticsService();
  static Future initialize() async {}
}