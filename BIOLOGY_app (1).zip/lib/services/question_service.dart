import 'package:flutter/foundation.dart';
class QuestionService extends ChangeNotifier {
  static final instance = QuestionService();
  static Future initialize() async {}
}