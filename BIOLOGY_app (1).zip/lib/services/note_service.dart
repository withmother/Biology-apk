import 'package:flutter/foundation.dart';
class NoteService extends ChangeNotifier {
  static final instance = NoteService();
  static Future initialize() async {}
}